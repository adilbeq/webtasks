<?php

class MC4WP_API_Connection_Exception extends MC4WP_API_Exception {}